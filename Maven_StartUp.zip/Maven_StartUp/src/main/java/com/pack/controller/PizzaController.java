package com.pack.controller;

import java.util.HashMap;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pack.model.Customer;
import com.pack.model.User;
import com.pack.service.PizzaOrderService;
import com.pack.service.UserService;
import com.pack.util.Util;

@Controller
public class PizzaController {
	
	@Autowired
	private UserService userService;
	String placeOrder;
	private Object customer;
	private Object pizzaOrder;
	private Object topping;
 
	
	@RequestMapping("toAdd")
	public String add(Model m)
	 
	{
		System.out.println("in controller");
		 
		return "final";
		 
	}
	@RequestMapping(value="/saveOrderController",method=RequestMethod.POST)
	public String saveOrder(@RequestParam("topping")int topping,Model m, @ModelAttribute("custmore")Customer customer,BindingResult result){
		System.out.println("into save order");
	}
	int pid=PizzaOrderService.placeOrder(customer,pizzaOrder,topping);
	m.addAttribute("pid",pid);
	if(result.hasErrors()){
		Model m;
		m.addAttribute("pizzaTopping",hm);
		return placeOrder;
	}
	else {
		return success;
}
	HashMap hm=new HashMap();
	@RequestMapping("/UtilController")
	public String getToppings(Model m)
	{
		System.out.println("into util controller");
		hm = Util.getToppings();
		System.out.println("hm"+hm);
		m.addAttribute("pizzaToppings",hm);
		m.addAttribute("customer",new Customer);
		
		return placeOrder;
		
	}
	
	
	 
}
