package com.pack.util;

import java.util.HashMap;

public class Util {

private static HashMap<Integer,String> toppings=new HashMap<Integer,String>();
   public static HashMap<Integer,String>getToppings(){
if(toppings.size()==0){
	   
	   toppings.put(30,"Capsicum");
	   toppings.put(50,"Mushroom");
	   toppings.put(70,"Jalapeno");
	   toppings.put(85,"paneer");
	   
	   
   }
return toppings;
}
}
