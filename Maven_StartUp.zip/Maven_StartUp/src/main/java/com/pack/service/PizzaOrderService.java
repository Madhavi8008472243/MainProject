package com.pack.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.pack.dao.pizzaOrderDAO;
import com.pack.model.Customer;
import com.pack.model.PizzaOrder;

public class PizzaOrderService {
	@Autowired
	private PizzaOrder pizzaOrder;
	public int plceOrder(Customer custmore,PizzaOrder pizza){
	float totalprice=0.0f;
	int pTopping = 0;
	totalprice=350+pTopping;
	pizza.setTotalPrice(totalprice);
	Object customer = null;
	int k=pizzaOrderDAO.placeorder(customer,pizza);
	return k;
	}
	public static int placeOrder(Object customer, Object pizzaOrder2, Object topping) {
		// TODO Auto-generated method stub
		return 0;
	}

}
