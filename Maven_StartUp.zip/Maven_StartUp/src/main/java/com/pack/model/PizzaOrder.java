package com.pack.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

public class PizzaOrder {
	int orderId1;
	private Object totalPrice;
	public int getOrderId(){
		return orderId1;
	}
	public void setOrderId(int orderId){
		this.orderId1=orderId;
	}
	public double getTotalPrice(){
		return getTotalPrice();
	}
	public void setTotalPrice(double totalprice){
		this.totalPrice=totalPrice;
	}

	@Id
	@GeneratedValue
	@Column(name="orderid")
	private int orderId;
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="customerid",unique=true)
	private Customer getCustomer(){
		Customer customerOrder = null;
		return customerOrder;
		
	}
	public void setCustomerOrder(Object customer) {
		// TODO Auto-generated method stub
		
	}
}
