package com.pack.model;

public class Customer {

}
