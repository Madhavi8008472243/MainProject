package com.pack.dao;

import javax.transaction.Transaction;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;

import com.mysql.cj.xdevapi.SessionFactory;
import com.pack.model.PizzaOrder;

public class pizzaOrderDAO {
	@Autowired
	private static SessionFactory sessionFactory;
	@Autowired
	private PizzaOrder pizzaOrder;
	public static int placeorder(Object customer, PizzaOrder pizza) {
		
	Session session= sessionFactory.openSession();
	org.hibernate.Transaction tx=session.beginTransaction();
	
	System.out.println("sessionggdf"+session);
	pizza.setCustomerOrder(customer);
	session.save(pizza);
	int pid= pizza.getOrderId();
	
	System.out.println("pid"+pid);
	tx.commit();
	session.close();
	return pid;
	}
	
	

}
